﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero1) && int.TryParse(textBox2.Text, out int numero2))
            {
                int result = numero1 * numero2;

                textBox3.Text = ("" + result);
            }
            else
            {
                textBox3.Text = "Erro. digite um numero.";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero1) && int.TryParse(textBox2.Text, out int numero2))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.1v - Metragem e Calculo para Pintura Residencial";
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear(); // chama metodo limpar
            }
            else
            {
                textBox3.Text = "Erro. nada para apagar.";
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int numero4)) // && int.TryParse(textBox5.Text, out int numero5) && int.TryParse(textBox6.Text, out int numero6))
            {
                int v2 = 360; // quantidade tinta por 1 metro quadrado
                int resultado = numero4 * v2; // quantidade de tinta por (n) tantos m²
                double qtdtinta = 3600; // 1 lata tem 3600ml(3,6)
                double resultado2 = resultado / qtdtinta; // quantidade de latas


                textBox5.Text = ("" + resultado);
                textBox6.Text = ("" + resultado2);
            }
            else
            {
                textBox5.Text = "Erro. digite um numero.";
                textBox6.Text = "Erro. digite um numero.";
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int numero4) && int.TryParse(textBox5.Text, out int numero5))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.1v - Metragem e Calculo para Pintura Residencial";
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear(); // chama metodo limpar
            }
            else
            {
                textBox5.Text = "Erro. nada para apagar.";
                textBox6.Text = "Erro. nada para apagar.";
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox11.Text, out int numero11) && int.TryParse(textBox12.Text, out int numero12))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.1v - Metragem e Calculo para Pintura Residencial";
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear(); // chama metodo limpar
            }
            else
            {
                textBox13.Text = "Erro. nada para apagar.";
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox11.Text, out int numero11) && int.TryParse(textBox12.Text, out int numero12))
            {
                int sum = numero11 + numero12;

                textBox13.Text = ("" + sum);
            }
            else
            {
                textBox13.Text = "Erro. digite um numero.";
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox11.Text, out int numero11) && int.TryParse(textBox12.Text, out int numero12))
            {
                int sub = numero11 - numero12;

                textBox13.Text = ("" + sub);
            }
            else
            {
                textBox13.Text = "Erro. digite um numero.";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox11.Text, out int numero11) && int.TryParse(textBox12.Text, out int numero12))
            {
                int div = numero11 / numero12;

                textBox13.Text = ("" + div);
            }
            else
            {
                textBox13.Text = "Erro. digite um numero.";
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox11.Text, out int numero11) && int.TryParse(textBox12.Text, out int numero12))
            {
                int mult = numero11 * numero12;

                textBox13.Text = ("" + mult);
            }
            else
            {
                textBox13.Text = "Erro. digite um numero.";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox7.Text, out int numero7)) 
            {
                int v2 = 3; // 3600ml(3,6) dividido por 3 sera 1200ml equivale a 3 demaos
                int resultado3 = numero7 * v2; // demao

                textBox8.Text = ("" + resultado3);
            }
            else
            {
                textBox8.Text = "Erro. digite um numero.";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox7.Text, out int numero7) && int.TryParse(textBox8.Text, out int numero8))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.1v - Metragem e Calculo para Pintura Residencial";
                textBox7.Clear();
                textBox8.Clear();                
            }
            else
            {
                textBox8.Text = "Erro. nada para apagar.";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox9.Text, out int numero9))
            {
                int v2 = 3; // 3600ml(3,6) dividido por 3 sera 1200ml equivale a 3 demaos
                int mq1 = 360; // 1 metro quadrado
                int lata1 = 3600; // 1 lata de tinta
                int resultado4 = numero9 * v2; // demao
                int calcqtdlitro = numero9 * lata1;  // quantidade tinta
                int calcmq = calcqtdlitro / mq1;  // metro quadrado


                textBox10.Text = ("" + calcmq);
                textBox14.Text = ("" + resultado4);
            }
            else
            {
                textBox10.Text = "Erro. digite um numero.";
                textBox14.Text = "Erro. digite um numero.";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox9.Text, out int numero9) && int.TryParse(textBox10.Text, out int numero10))
            {
                this.Text = "Sistema - $safeprojectname$ 0.0.0.1v - Metragem e Calculo para Pintura Residencial";
                textBox9.Clear();
                textBox10.Clear();
                textBox14.Clear();
            }
            else
            {
                textBox10.Text = "Erro. nada para apagar.";
                textBox14.Text = "Erro. nada para apagar.";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Text = "Info";
            // classe, metodo, string(texto)
            MessageBox.Show("Info\n"
            + "\nEste software foi desenvolvido com variaveis inteiras entao nao aceita numeros com virgula ex: 2,90 metros mude para 3 metros.\n"
            + "\nPara calcular a Area de Muro ou Parede [Metro Quadrado] - Muro ou Parede de Tamanho Regular [4 lados iguais] - iremos calcular a altura vezes a largura.\n"
            + "\n Para Calcular Pintura com Tinta sem diluicao:\n"
            + "\n Com base em uma lata de tinta de 3,6L e com base em uma parede com (A 2,70 metros x L 3,70 metros) temos que A x L = a 10MQ, e entao temos que 1 lata com 3600ml de tinta dividido por 10 tera 360ml para cada 1MQ, esse sera o padrao do calculo 360ml = 1MQ, então tem se que Quaisquer(N) metros quadrados x 360ml = a (N) litros de tinta e esse resultado dividido por 3600ml sera igual a (N) quantidade de latas de tinta.\n"
            + "\nPara calcular uma demao: \n"
            + "\nPara pintar uma demao temos que uma bandeja de tinta tem 1000ml como referencia por demao, e uma lata de tinta tem 3600ml entao temos que uma lata tem 1200ml por demao ja que 1200ml vs 3 = a 3600ml(3,6L). Uma demao equivale a uma pintura completa de uma parede. Geralmente eh necessario de duas a tres demaos para pintar uma parede.\n");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Text = "Sobre";
            MessageBox.Show("Sobre\n" + "\nSoftware: Sistema - $safeprojectname$ 0.0.0.1v - Metragem e Calculo para Pintura Residencial \n" + "\nAuthor: PHNO" + "\nData Release: 20/09/2024" + "\nVersao Codigo: 0.0.0.1v" + "\nReplit: @PHNO, @PHREPLIT" + "\nE-mail: phreplit@gmail.com");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Text = "Sistema - $safeprojectname$ 0.0.0.1v - Metragem e Calculo para Pintura Residencial";
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear(); // chama metodo limpar
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
        }
    }
}
